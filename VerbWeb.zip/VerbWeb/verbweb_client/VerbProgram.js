

function setup() {
    createCanvas(windowWidth, windowHeight);
  }
  var dictionary = {

    
    suffix : "ся",
    aspect: ["uv.", "v."],
  
    give : {
        verbStem : "дать",
        verbForms : ["дам", "дашь", "даст", "дадим", "дадите", "дадут"],
        mainDef : "geben",
        subDef: [],
        prefix : [ "за" , "из", "от" , "пере" , 
        "по" , "пре" , "при" , "про" , "раз", "соз"]
    },
    go : {
        verbStem : "ходить",
        verbForms : ["хожу", "ходишь", "ходят"],
        mainDef: "gehen",
        subDef : ["hineingehen, eintreten" , "hinausgehen" , "erreichen, gehen bis, anlangen"],
        prefix : ["в" , "вы" , "до" , "за" , "ис" , "на" , "об" , "от" , "пере" , 
        "под" , "пре" , "при" , "про" , "снис" , "с" , "у"]
                }

            }

   function drawGo() {
      /*background(102, 102, 102);*/
      background(242, 242, 242);
      var verbToDraw = dictionary.go;
      
       // derived terms in ellipses
       for( var i = 0; i < 16; i++) {
          var scalar = 365;
          var scalarX = 355;
          var scalarY = 360;
          var circle = i * 22.5 * Math.PI / 180;
          
          
            fill(0,0,0);
            line(windowWidth/2, windowHeight/2, windowWidth/2 + scalar * Math.cos(circle), windowHeight/2 + scalar * Math.sin(circle));
            fill(255, 204, 0);
            ellipse(windowWidth/2 + scalar * Math.cos(circle), windowHeight/2 + scalar * Math.sin(circle), 140, 75);
            fill(0,0,0);
            textSize(16);
            textAlign(CENTER);
            text(verbToDraw.prefix[i] + verbToDraw.verbStem, windowWidth/2 + scalarX * Math.cos(circle), windowHeight/2 + scalarY * Math.sin(circle));
           
        } 
        
    
        
    
        fill(255, 204, 0);
        ellipse(windowWidth/2, windowHeight/2, 350, 100);
        fill(0,0,0);
        textSize(26);
        textAlign(CENTER);
        text(verbToDraw.verbStem + " ", windowWidth/2, windowHeight/2);
        textSize(18);
        text(dictionary.aspect[0], windowWidth/2 + 60, windowHeight/2); 
        textSize(14);
        text("1. Sg. " + verbToDraw.verbForms[0]+ ", 2. Sg. " + verbToDraw.verbForms[1] + ", 3. Pl. " +
        verbToDraw.verbForms[2], windowWidth/2, windowHeight/2 + 20);
  
}


function drawGive() {
    /*background(102, 102, 102);*/
    background(242, 242, 242);
    var verbToDraw = dictionary.give;
    
     // derived terms in ellipses
     for( var i = 0; i < 16; i++) {
        var scalar = 365;
        var scalarX = 355;
        var scalarY = 360;
        var circle = i * 36 * Math.PI / 180;
        
        
          fill(0,0,0);
          line(windowWidth/2, windowHeight/2, windowWidth/2 + scalar * Math.cos(circle), windowHeight/2 + scalar * Math.sin(circle));
          fill(0, 64, 255);
          ellipse(windowWidth/2 + scalar * Math.cos(circle), windowHeight/2 + scalar * Math.sin(circle), 140, 75);
          fill(0,0,0);
          textSize(16);
          textAlign(CENTER);
          text(verbToDraw.prefix[i] + verbToDraw.verbStem, windowWidth/2 + scalarX * Math.cos(circle), windowHeight/2 + scalarY * Math.sin(circle));
         
      }
  
      
  
      fill(0, 64, 255);
      ellipse(windowWidth/2, windowHeight/2, 350, 100);
      fill(0,0,0);
      textSize(26);
      textAlign(CENTER);
      text(verbToDraw.verbStem + " ", windowWidth/2, windowHeight/2);
      textSize(18);
      text(dictionary.aspect[0], windowWidth/2 + 60, windowHeight/2); 
      textSize(14);
      text("1. Sg. " + verbToDraw.verbForms[0]+ ", 2. Sg. " + verbToDraw.verbForms[1] + ", 3. Sg. " +
      verbToDraw.verbForms[2] + ", 1. Pl. " + verbToDraw.verbForms[3] + ", 2. Pl. " + verbToDraw.verbForms[4] + ", 3. Pl. " + verbToDraw.verbForms[5] + ",", windowWidth/2, windowHeight/2 + 20);
      text("1. Pl. " + verbToDraw.verbForms[3] + ", 2. Pl. " + verbToDraw.verbForms[4] + ", 3. Pl. " + verbToDraw.verbForms[5], windowWidth/2, windowHeight/2 + 20);
}


       


        
      
     
         
    

